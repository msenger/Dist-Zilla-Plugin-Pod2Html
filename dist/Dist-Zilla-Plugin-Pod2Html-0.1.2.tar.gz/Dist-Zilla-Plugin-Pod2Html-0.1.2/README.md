It creates CSS-rich HTML pages from the POD-aware files (Perl).
